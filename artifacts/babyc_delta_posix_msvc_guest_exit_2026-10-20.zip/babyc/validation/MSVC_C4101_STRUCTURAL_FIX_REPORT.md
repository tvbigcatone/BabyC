# BabyC POSIX/MSVC/guest-exit follow-up — 2026-10-20

## Applied
- Structural C4101 declaration scoping in five POSIX implementation files.
- Corrected native process-exit fallback in Unix and Windows platform layers so `exit(0)` remains status 0.
- Hardened the interpreted guest-thread exit-point path: unwind IR call frames created by the callback, remove stack-owned value proxies, and restore interpreter heap/stack pointers after guest `exit()` longjmps.
- Corrected saved-frame pointer types after MSVC surfaced C4133; removed the unused local `i` from `IrAnnotateExprBody` after MSVC surfaced C4101.
- Added `src/tests/posix/guest_exit_zero.c`.

## Validation evidence
- Linux/GCC build: PASS on the latest run.
- MSVC Release Win32 build: PASS on the initial run; latest post-fix build pending.
- Earlier x64 build failed with a transient `C1083 Permission denied` creating `include.obj`; retry on the latest commit is pending.
- Dual suite: A-IR 1083/1083 and C-IR-SHADOW0 1083/1083; B-NO_IR 1061/1083 (22 failures). The suite is reported as failed, not as a pass.
- Focused POSIX thread regressions including Linear STRICT are now wired to run even if the dual suite fails; latest results pending.
- Linear STRICT is not certified until those focused runs complete.
